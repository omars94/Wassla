<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DemandController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ServiceProviderController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('demand/all', [DemandController::class, 'index']);
Route::post('demand/add', [DemandController::class, 'store']);
Route::get('demand/delete/${id}', [DemandController::class, 'destroy']);
Route::post('demand/edit/${id}', [DemandController::class, 'update']);

Route::get('service/all', [ServiceController::class, 'index']);
Route::post('service/add', [ServiceController::class, 'store']);
Route::get('service/delete/${id}', [ServiceController::class, 'destroy']);
Route::post('service/edit/${id}', [ServiceController::class, 'update']);


Route::get('serviceProvider/helper/{service_type}', [ServiceProviderController::class, 'getDemandServiceProviders']);
Route::get('serviceProvider/all', [ServiceProviderController::class, 'index']);
Route::post('serviceProvider/add', [ServiceProviderController::class, 'store']);
Route::get('serviceProvider/delete/{id}', [ServiceProviderController::class, 'destroy']);
Route::post('serviceProvider/edit/{id}', [ServiceProviderController::class, 'update']);