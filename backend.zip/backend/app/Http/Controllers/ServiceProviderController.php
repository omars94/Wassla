<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceProvider;

class ServiceProviderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function getDemandServiceProviders($service_type){
        $service_providers =  ServiceProvider::get()->where('service_type', 'like', $service_type);

        $response = [
            'success' => true,
            'data'    => $service_providers,
            // 'message' => "Mabruk",
        ];
        return $response;
    }

    public function index()
    {
        $items = ServiceProvider::get();
        $response = [
            'success' => true,
            'data'    => $items,
            // 'message' => "Mabruk",
        ];
        return response()->json($response, 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

     //CRUD LARAVEL
    public function store(Request $request)
    {
       $data =  ServiceProvider::create($request->all());
       $id = $data->id;
       $response = [
        'success' => true,
        "data"=>$request->all(),
        "id"=>$id
    ];
        return response()->json($response, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $service = ServiceProvider::find($id);
        $service->update($request->all());
        $response = [
         'success' => true,
         "data"=>$service,
     ];
         return response()->json($response, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        ServiceProvider::find($id)->delete();
        $response = [
            'success' => true,
        ];
        return response()->json($response, 200);
    }
}
