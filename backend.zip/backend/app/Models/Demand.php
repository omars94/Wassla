<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Orchid\Attachment\Attachable;
use Orchid\Filters\Filterable;
use Orchid\Screen\AsSource;

class Demand extends Model
{
    use HasFactory, Attachable, Filterable, AsSource;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'firstname',
        'lastname',
        'phone',
        'service_type',
        'area',
        'city',
        'reason',
        'approved',
    ];

    public function service_providers(){
        return $this->hasMany('App\ServiceProvider');
    }
}
