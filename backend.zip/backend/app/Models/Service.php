<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Orchid\Attachment\Attachable;
use Orchid\Filters\Filterable;
use Orchid\Screen\AsSource;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Service extends Model
{
    use AsSource,HasFactory, Filterable, Attachable;


    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    use Filterable;

    /**
     * @var array
     */
    protected $allowedFilters = [
        'title_en',
        'title_ar',
        'short_description_en',
        'short_description_ar',
        'icon',
    ];

    /**
     * @var array
     */
    protected $allowedSorts = [
        'title_en',
        'title_ar',
        'short_description_en',
        'short_description_ar',
        'icon',
    ];
    protected $fillable = [
        'title_en',
        'title_ar',
        'short_description_en',
        'service_type',
        'short_description_ar',
        'icon',
        'image'
    ];
}
