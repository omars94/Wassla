<?php

namespace App\Orchid\Screens;

use Orchid\Support\Facades\Layout;
use Orchid\Screen\Screen;
// use App\Orchid\Screens\TD;
use Orchid\Screen\TD;

class ServicesScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Services';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::table('services',[
                TD::make('id'),
                TD::make('title_en'),
            ])
        ];
    }
}
