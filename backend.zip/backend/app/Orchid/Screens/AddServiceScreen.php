<?php

namespace App\Orchid\Screens;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\Mail;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\TextArea;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Screen;
use Orchid\Support\Facades\Alert;
use App\Http\Controllers\ServiceController;

class AddServiceScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Add Service';
    public $description = 'add new service';


    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Add Service')
                ->icon('paper-plane')
                ->method('addService')
        ];
    }
    public function addService(Request $request)
    {
        // $request->validate([
        //     'title_en' => 'required',
        //     'title_ar' => 'required',
        //     'short_description_ar' => 'required',
        //     'short_description_en' => 'required',
        //     'image' => 'required',
        //     'icon' => 'required',
        // ]);

        // Route::post('service/add', [ServiceController::class, 'store']);
        // ServiceController::class->store($request);
        Service::create($request->all());
        Alert::info('Your new service was added successfully.');
    }
    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return  [
            Layout::rows([  
                Input::make('title_en')
                    ->title('Title English')
                    ->required()
                    ->placeholder('In-Home Babysitting')
                    ->help('Enter the title in english for your service'),
                Input::make('title_ar')
                    ->title('Title Arabic')
                    ->required()
                    ->placeholder('مجالسة اطفال')
                    ->help('Enter the title in arabic for your service'),
                Input::make('image')
                    ->title('Image')
                    ->required()
                    ->placeholder('Service Image')
                    ->help('Enter the image that you would like to display for this service.'),
                Input::make('icon')
                    ->title('Icon')
                    ->required()
                    ->placeholder('cooking or babysitter or elderly')
                    ->help('Enter the icon that you would like to display for this service.'),
                TextArea::make('short_description_en')
                    ->title('English Description')
                    ->rows(5)
                    ->required()
                    ->placeholder('Insert text here ...')
                    ->help('Add the description in english for the service.'),
                TextArea::make('short_description_ar')
                    ->rows(5)
                    ->title('Arabic Description')
                    ->required()
                    ->placeholder('Insert text here ...')
                    ->help('Add the description in arabic for the service.')
            ])
        ];
    }
}
