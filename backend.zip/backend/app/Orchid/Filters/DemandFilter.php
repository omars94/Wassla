<?php

namespace App\Orchid\Filters;

use Illuminate\Database\Eloquent\Builder;
use Orchid\Filters\Filter;
use Orchid\Screen\Field;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\DateTimer;

class DemandFilter extends Filter
{
    /**
     * @var array
     */
    public $parameters = ['firstname','lastname','service_type','phone','area','city', 'toDate','fromDate'];


    /**
     * @return string
     */
    public function name(): string
    {
        return 'Filters';
    }

    /**
     * @param Builder $builder
     *
     * @return Builder
     */
    public function run(Builder $builder): Builder
    {
        
        return $builder
        ->where('firstname','like','%'.$this->request->get('firstname').'%')
        ->where('lastname','like','%'.$this->request->get('lastname').'%')
        ->where('phone','like','%'.$this->request->get('phone').'%')
        ->whereBetween('created_at', 
            [   
                $this->request->get('fromDate').' 00:00:00',
                $this->request->get('toDate').' 23:59:59'
            ]);
        // ->where('service_type','like','%'.$this->request->get('service_type').'%')
        // ->where('area','like','%'.$this->request->get('area').'%')
        // ->where('city','like','%'.$this->request->get('city').'%')
        // ->where('fromDate','between', $this->request->get('created_at'));
        // ->whereRaw(
        //     "(created_at >= ? AND created_at <= ?)", 
        //     [
        //     //    $fromDate ." 00:00:00", 
        //     //    $toDate ." 23:59:59"
        //     ]);
    }

    /**
     * @return Field[]
     */
    public function display(): array
    {
        //
        return [
            Input::make('firstname')
                ->type('text')
                ->value($this->request->get('firstname'))
                ->placeholder('Search First Name')
                ->title('First Name'),
            Input::make('lastname')
                ->type('text')
                ->value($this->request->get('lastname'))
                ->placeholder('Search Last Name')
                ->title('Last Name'),
            Input::make('phone')
                ->type('text')
                ->value($this->request->get('phone'))
                ->placeholder('Search Phone #')
                ->title('Phone #'),
            DateTimer::make('fromDate')
                ->title('Start Date')
                ->format('Y-m-d'),
            DateTimer::make('toDate')
                ->title('End Date')
                ->format('Y-m-d')
            // Input::make('service_type')
            //     ->type('text')
            //     ->value($this->request->get('service_type'))
            //     ->placeholder('Search Service Type')
            //     ->title('Service Type'),
            // Input::make('area')
            //     ->type('text')
            //     ->value($this->request->get('area'))
            //     ->placeholder('Search Area')
            //     ->title('Area'),
            // Input::make('city')
            //     ->type('text')
            //     ->value($this->request->get('city'))
            //     ->placeholder('Search City')
            //     ->title('City'),
            

        ];
    }
}
