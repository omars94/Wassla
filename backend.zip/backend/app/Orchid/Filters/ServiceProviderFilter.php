<?php

namespace App\Orchid\Filters;

use Illuminate\Database\Eloquent\Builder;
use Orchid\Filters\Filter;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Field;

class ServiceProviderFilter extends Filter
{
    /**
     * @var array
     */
    public $parameters = ['firstname','lastname','service_type','phone','age','area','city'];

    /**
     * @return string
     */
    public function name(): string
    {
        return 'Filter';
    }

    /**
     * @param Builder $builder
     *
     * @return Builder
     */
    public function run(Builder $builder): Builder
    {
        return $builder
        ->where('firstname','like','%'.$this->request->get('firstname').'%')
        ->where('lastname','like','%'.$this->request->get('lastname').'%')
        ->where('service_type','like','%'.$this->request->get('service_type').'%')
        ->where('phone','like','%'.$this->request->get('phone').'%')
        ->where('age','like','%'.$this->request->get('age').'%')
        ->where('area','like','%'.$this->request->get('area').'%')
        ->where('city','like','%'.$this->request->get('city').'%');
    }

    /**
     * @return Field[]
     */
    public function display(): array
    {
        //
        return [
            Input::make('firstname')
                ->type('text')
                ->value($this->request->get('firstname'))
                ->placeholder('Search First Name')
                ->title('First Name'),
            Input::make('lastname')
                ->type('text')
                ->value($this->request->get('lastname'))
                ->placeholder('Search Last Name')
                ->title('Last Name'),
            Input::make('phone')
                ->type('text')
                ->value($this->request->get('phone'))
                ->placeholder('Search Phone #')
                ->title('Phone #'),
            Input::make('service_type')
                ->type('text')
                ->value($this->request->get('service_type'))
                ->placeholder('Search Service Type')
                ->title('Service Type'),
            Input::make('age')
                ->type('text')
                ->value($this->request->get('age'))
                ->placeholder('Search Age')
                ->title('Age'),
            Input::make('area')
                ->type('text')
                ->value($this->request->get('area'))
                ->placeholder('Search Area')
                ->title('Area'),
            Input::make('city')
                ->type('text')
                ->value($this->request->get('city'))
                ->placeholder('Search City')
                ->title('City'),
        ];
    }
}
