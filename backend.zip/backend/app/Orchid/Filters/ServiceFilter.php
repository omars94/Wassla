<?php

namespace App\Orchid\Filters;

use Illuminate\Database\Eloquent\Builder;
use Orchid\Filters\Filter;
use Orchid\Screen\Field;
use Orchid\Screen\Fields\Input;

class ServiceFilter extends Filter
{
    /**
     * @var array
     */
    public $parameters = ['title_en','title_ar','short_description_en','short_description_ar','service_type',];

    /**
     * @return string
     */
    public function name(): string
    {
        return 'Filter';

    }

    /**
     * @param Builder $builder
     *
     * @return Builder
     */
    public function run(Builder $builder): Builder
    {
        return $builder
        ->where('title_en','like','%'.$this->request->get('title_en').'%')
        ->where('title_ar','like','%'.$this->request->get('title_ar').'%')
        ->where('short_description_en','like','%'.$this->request->get('short_description_en').'%')
        ->where('short_description_ar','like','%'.$this->request->get('short_description_ar').'%')
        ->where('service_type','like','%'.$this->request->get('service_type').'%');
    }

    /**
     * @return Field[]
     */
    public function display(): array
    {
        //
        return [
            Input::make('title_en')
                ->type('text')
                ->value($this->request->get('title_en'))
                ->placeholder('Search title english')
                ->title('Title English'),
            Input::make('title_ar')
                ->type('text')
                ->value($this->request->get('title_ar'))
                ->placeholder('Search title arabic')
                ->title('Title Arabic'),
            Input::make('short_description_en')
                ->type('text')
                ->value($this->request->get('short_description_en'))
                ->placeholder('Search description english')
                ->title('Title English'),
            Input::make('short_description_ar')
                ->type('text')
                ->value($this->request->get('short_description_ar'))
                ->placeholder('Search description arabic')
                ->title('Description Arabic'),
            Input::make('service_type')
                ->type('text')
                ->value($this->request->get('service_type'))
                ->placeholder('Search Service Type name')
                ->title('Service Type')
        ];
    }
}
