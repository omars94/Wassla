<?php

namespace App\Orchid\Resources;

use Orchid\Crud\Resource;
use Orchid\Screen\TD;
use Orchid\Screen\Sight;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Group;
use Orchid\Screen\Fields\Cropper;
use Orchid\Screen\Fields\Upload;
use Orchid\Screen\Fields\Picture;


use Illuminate\Support\Str;

use Orchid\Screen\Fields\TextArea;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;

use App\Orchid\Filters\ServiceFilter;


class ServiceResource extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Service::class;

    /**
     * Get the fields displayed by the resource.
     *
     * @return array
     */
    public function fields(): array
    {
        return [
            Group::make([
                Input::make('title_en')
                ->title('Title english')
                ->placeholder('Enter english title here'),
                Input::make('title_ar')
                ->title('Title arabic')
                ->placeholder('Enter arabic title here'),
            ])->autoWidth(),
            Group::make([
                TextArea::make('short_description_en')
                ->title('Description english')
                ->placeholder('Enter english description here'),
                TextArea::make('short_description_ar')
                ->title('Description arabic')
                ->placeholder('Enter arabic description here'),
            ])->fullWidth(),
            Group::make([
                Picture::make('image')
                ->title('Image')
                ->acceptedFiles('image/*')
                ->targetUrl()->center(),
                Picture::make('icon')
                ->title('Icon')
                ->acceptedFiles('image/*')->targetUrl()->autoWidth()->maxFileSize(0.2),
                ])->fullWidth(),            
            Input::make('service_type')
            ->title('Service Type')
            ->placeholder('Enter Service Type name here'),
        ];
    }

    /**
     * Get the columns displayed by the resource.
     *
     * @return TD[]
     */
    public function columns(): array
    {
        return [
            TD::make('id'),
            TD::make('title_en', 'English Title')
            ->render(function ($model) {
                return Str::limit($model->title_en, 50);
            }),
            TD::make('title_ar', 'Arabic Title')
            ->render(function ($model) {
                return Str::limit($model->title_ar, 50);
            }),
            TD::make('short_description_en', 'English Description')
            ->render(function ($model) {
                return Str::limit($model->short_description_en, 50);
            }),
            TD::make('short_description_ar', 'Arabic Description')
            ->render(function ($model) {
                return Str::limit($model->short_description_ar, 50);
            }),
            TD::make('service_type', 'Service Type')
            ->render(function ($model) {
                return Str::limit($model->service_type, 50);
            }),
            TD::make('image', 'Image')
            ->render(function ($model) {
                return "<img src='{$model->image}'
                      alt='sample'
                      style='width:50px; height:50px;float:left;' >";
            }),
            TD::make('icon', 'Icon')
            ->render(function ($model) {
                return "<img src='{$model->icon}'
                alt='sample'
                style='width:50px; height:50px;float:left;' >";
            }),
            TD::make('created_at', 'Date')
                ->render(function ($model) {
                    return "<div>Created at: {$model->created_at->toDateTimeString()}<br/>Updated at: {$model->updated_at->toDateTimeString()}</div>";
            }),
            
        ];
    }

    /**
     * Get the sights displayed by the resource.
     *
     * @return Sight[]
     */
    public function legend(): array
    {
        return [
            // Sight::make('id','id'),
            Sight::make('title_en','Title English'),
            Sight::make('title_ar','Title Arabic'),
            Sight::make('short_description_en','Description English'),
            Sight::make('title_ar','Description Arabic'),
            Sight::make('service_type','Service Type'),
            Sight::make('image','Image')->render(function ($model){
                return "<img src='{$model->image}'
                alt='sample'
                style='width:300px; height:300px;float:left;'
                class='mw-100 img-fluid'>";
            }),
            Sight::make('icon','Icon')->render(function ($model){
                return "<img src='{$model->icon}'
                alt='sample'
                style='width:50px; height:50px; float:left;'
                class='mw-100 img-fluid'>";
            }),
            
        ];
    }

    /**
     * Get the filters available for the resource.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            ServiceFilter::class
        ];
    }
}
