<?php

namespace App\Orchid\Resources;

use Orchid\Crud\Resource;
use Orchid\Screen\TD;
use Orchid\Screen\Sight;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Group;
use Illuminate\Support\Str;
use App\Orchid\Filters\ServiceProviderFilter;

class ServiceProviderResource extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\ServiceProvider::class;

    /**
     * Get the fields displayed by the resource.
     *
     * @return array
     */
    public function fields(): array
    {
        return [
            Group::make([
                Input::make('firstname')
                ->title('First name')
                ->placeholder('Enter First name here'),
                Input::make('lastname')
                ->title('Last name')
                ->placeholder('Enter Last name here'),
            ])->autoWidth(),
            Input::make('service_type')
            ->title('Service Type')
            ->placeholder('Enter Service Type here'),
            Input::make('phone')
            ->title('Phone #')
            ->placeholder('Enter phone number here'),
            Input::make('age')
            ->title('Age ')
            ->placeholder('Enter age here'),
            Group::make([
                Input::make('area')
                ->title('Area ')
                ->placeholder('Enter area here'),
                Input::make('city')
                ->title('City')
                ->placeholder('Enter city here'),
            ])->autoWidth()
        ];
    }

    /**
     * Get the columns displayed by the resource.
     *
     * @return TD[]
     */
    public function columns(): array
    {
        return [
            TD::make('id'),
            TD::make('firstname', 'First Name')
            ->render(function ($model) {
                return Str::limit($model->firstname, 50);
            }),
            TD::make('lastname', 'Last Name')
            ->render(function ($model) {
                return Str::limit($model->lastname, 50);
            }),
            TD::make('phone', 'Phone #')
            ->render(function ($model) {
                return Str::limit($model->phone, 50);
            }),
            TD::make('service_type', 'Service Type')
            ->render(function ($model) {
                return Str::limit($model->service_type, 50);
            }),
            TD::make('age', 'Age')
            ->render(function ($model) {
                return Str::limit($model->age, 50);
            }),
            TD::make('area', 'Area')
            ->render(function ($model) {
                return Str::limit($model->area, 50);
            }),
            TD::make('city', 'City')
            ->render(function ($model) {
                return Str::limit($model->city, 50);
            }),
            TD::make('created_at', 'Date')
            ->render(function ($model) {
                return "<div>Created at: {$model->created_at->toDateTimeString()}<br/>Updated at: {$model->updated_at->toDateTimeString()}</div>";
            }),
        ];
    }

    /**
     * Get the sights displayed by the resource.
     *
     * @return Sight[]
     */
    public function legend(): array
    {
        return [
            Sight::make('firstname','First Name'),
            Sight::make('lastname','Last Name'),
            Sight::make('phone','Phone #'),
            Sight::make('service_type','Service Type'),
            Sight::make('age','Age'),
            Sight::make('area','Area'),
            Sight::make('city','City'),
        ];
    }

    /**
     * Get the filters available for the resource.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            ServiceProviderFilter::class
        ];
    }
}
