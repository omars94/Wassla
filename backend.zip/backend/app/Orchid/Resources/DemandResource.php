<?php

namespace App\Orchid\Resources;

use Orchid\Crud\Resource;
use Orchid\Screen\TD;
use Orchid\Screen\Sight;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Group;
use Orchid\Screen\Fields\TextArea;
use Orchid\Screen\Fields\Relation;
use Orchid\Screen\Fields\Select;
use Illuminate\Support\Str;
use App\Orchid\Filters\DemandFilter;
use App\Models\ServiceProvider;

class DemandResource extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Demand::class;
    /**
     * Get the fields displayed by the resource.
     *
     * @return array
     */
    public function fields(): array
    {
        return [
            Group::make([
                Input::make('firstname')
                    ->title('First name')
                    ->placeholder('Enter First name here'),
                Input::make('lastname')
                    ->title('Last name')
                    ->placeholder('Enter Last name here'),
            ])->autoWidth(),
            Input::make('phone')
                ->title('Phone #')
                ->placeholder('Enter phone number here'),
            Input::make('service_type')
                ->title('Service Type')
                ->placeholder('Enter Service type here'),
            Select::make('approved')
                ->options([
                    -1 => 'On Hold',
                    1 => 'Approved',
                    0 => 'Disapproved',
                ])
                ->title('Approve or disapprove'),
            TextArea::make('reason')
                ->title('Reason ')
                ->placeholder('Enter reason here'),
            Group::make([
                Input::make('area')
                    ->title('Area ')
                    ->placeholder('Enter area here'),
                Input::make('city')
                    ->title('City')
                    ->placeholder('Enter city here'),
            ])->autoWidth(),

        ];
    }

    /**
     * Get the columns displayed by the resource.
     *
     * @return TD[]
     */
    public function columns(): array
    {
        return [
            TD::make('id'),
            TD::make('firstname', 'First Name')
            ->render(function ($model) {
                return Str::limit($model->firstname, 50);
            }),
            TD::make('lastname', 'Last Name')
            ->render(function ($model) {
                return Str::limit($model->lastname, 50);
            }),
            TD::make('phone', 'Phone #')
            ->render(function ($model) {
                return Str::limit($model->phone, 50);
            }),
            TD::make('service_type', 'Service Type')
            ->render(function ($model) {
                return Str::limit($model->service_type, 50);
            }),
            TD::make('area', 'Area')
            ->render(function ($model) {
                return Str::limit($model->area, 50);
            }),
            TD::make('city', 'City')
            ->render(function ($model) {
                return Str::limit($model->city, 50);
            }),
            TD::make('reason', 'Reason')
            ->render(function ($model) {
                return Str::limit($model->reason, 50);
            }),
            TD::make('service_type', 'Providers')
            ->render(function ($model){
        $serviceProviders = ServiceProvider::get();
                return "<button><a href=\"service-provider-resources?service_type={$model->service_type}\" >Check Possible<br/>Service Providers</a></button>";
            }),
           
            TD::make('created_at', 'Date')
                ->render(function ($model) {
                    return "<div>Created at: {$model->created_at->toDateTimeString()}<br/>Updated at: {$model->updated_at->toDateTimeString()}</div>";
            }),
           
        ];
    }

    /**
     * Get the sights displayed by the resource.
     *
     * @return Sight[]
     */
    public function legend(): array
    {
        return [
            Sight::make('firstname','First Name'),
            Sight::make('lastname','Last Name'),
            Sight::make('phone','Phone #'),
            Sight::make('service_type','Service Type'),
            Sight::make('reason','Reason'),
            Sight::make('approved','Approved'),
            Sight::make('area','Area'),
            Sight::make('city','City'),
        ];
    }

    /**
     * Get the filters available for the resource.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            DemandFilter::class
        ];
    }
}
