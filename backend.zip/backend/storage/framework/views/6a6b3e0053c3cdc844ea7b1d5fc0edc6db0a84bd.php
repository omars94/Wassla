<div class="d-block bg-white rounded shadow-sm mb-3">
    <div class="row g-0">

            <?php if(empty(!$image)): ?>
                <div class="col-md-4">
                    <div class="h-100" style="display: contents">
                        <img src="<?php echo e($image); ?>" class="img-fluid img-card">
                    </div>
                </div>
            <?php endif; ?>

            <div class="col">
                <div class="card-body h-full p-4">
                    <div class="row d-flex align-items-center">
                        <div class="col-auto">
                            <h5 class="card-title">
                                <?php if(empty(!$color)): ?><i class="text-<?php echo e($color); ?>">●</i><?php endif; ?>
                                <?php echo e($title ?? ''); ?>

                            </h5>
                        </div>

                        <?php if(count($commandBar) > 0): ?>
                            <div class="col-auto ms-auto text-end">
                                <div class="btn-group command-bar">
                                    <button class="btn btn-link btn-sm dropdown-toggle dropdown-item p-2" type="button"
                                            data-bs-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                        <?php if (isset($component)) { $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc = $component; } ?>
<?php $component = $__env->getContainer()->make(Orchid\Icons\IconComponent::class, ['path' => 'options-vertical']); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc)): ?>
<?php $component = $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc; ?>
<?php unset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc); ?>
<?php endif; ?>

                                    </button>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow bg-white"
                                         x-placement="bottom-end">
                                        <?php $__currentLoopData = $commandBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $command): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $command; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-text layout-wrapper layout-wrapper-no-padder"><?php echo $description ?? ''; ?></div>
                </div>
            </div>

        </div>
</div>
<?php /**PATH /Users/cyclopath/Desktop/ShiftProject/backend/vendor/orchid/platform/resources/views/layouts/card.blade.php ENDPATH**/ ?>