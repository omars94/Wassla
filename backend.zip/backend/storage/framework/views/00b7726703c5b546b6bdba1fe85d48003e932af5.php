<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <input type="range" class="form-range" <?php echo e($attributes); ?>>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/cyclopath/Desktop/ShiftProject/backend/vendor/orchid/platform/resources/views/fields/range.blade.php ENDPATH**/ ?>