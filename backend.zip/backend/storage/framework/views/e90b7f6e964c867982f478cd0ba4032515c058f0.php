<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH /Users/cyclopath/Desktop/ShiftProject/backend/vendor/orchid/platform/resources/views/partials/notification-wrap.blade.php ENDPATH**/ ?>