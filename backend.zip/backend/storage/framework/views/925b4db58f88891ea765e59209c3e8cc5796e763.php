<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
   <?php if(empty(!$value)): ?>
        <p <?php echo e($attributes); ?>>
            <?php echo e($value); ?>

        </p>
   <?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/cyclopath/Desktop/ShiftProject/backend/vendor/orchid/platform/resources/views/fields/label.blade.php ENDPATH**/ ?>